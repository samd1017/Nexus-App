---
title: "Review-00012-nqr"
tags: ["planning"]
status: active
type: daily
created: 2020-11-04
updated: 2020-12-08
due: 2020-11-07
---

Frontmatter properties allow testing of Bases and property-based queries.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Dates and status values support filtering and sorting experiments.

## Review-00012-nqr

Generated for large-vault performance testing.

---
title: "Note-00009-edz"
tags: ["health", "work"]
status: done
type: resource
created: 2020-02-25
updated: 2020-02-25
---

Frontmatter properties allow testing of Bases and property-based queries.

## Note-00009-edz

Generated for large-vault performance testing.

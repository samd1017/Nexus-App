---
title: "Summary-00065-qid"
tags: ["idea"]
status: reference
type: note
created: 2020-01-29
updated: 2020-02-29
---

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

[[Review-00036-fvq]]

## Summary-00065-qid

Generated for large-vault performance testing.

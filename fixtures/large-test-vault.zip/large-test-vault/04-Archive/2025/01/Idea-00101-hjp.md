---
title: "Idea-00101-hjp"
tags: ["finance", "important"]
status: someday
type: area
created: 2020-08-07
updated: 2020-08-25
priority: low
---

Random wikilinks exercise the backlink and local graph features.

Frontmatter properties allow testing of Bases and property-based queries.

## Idea-00101-hjp

Generated for large-vault performance testing.

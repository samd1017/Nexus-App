---
title: "Note-00173-iza"
tags: ["reference", "learning", "personal"]
status: someday
type: resource
created: 2021-12-19
updated: 2022-02-02
---

Frontmatter properties allow testing of Bases and property-based queries.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

[[Memo-00162-sxq]] [[Brief-00038-ajx]]

## Note-00173-iza

Generated for large-vault performance testing.

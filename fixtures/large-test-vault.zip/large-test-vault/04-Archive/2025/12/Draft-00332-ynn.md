---
title: "Draft-00332-ynn"
tags: ["work", "writing"]
status: reference
type: note
created: 2021-11-20
updated: 2021-12-07
priority: medium
---

Random wikilinks exercise the backlink and local graph features.

Frontmatter properties allow testing of Bases and property-based queries.

This is a generic test note generated for large vault performance testing.

## Draft-00332-ynn

Generated for large-vault performance testing.

---
title: "Concept-00032-bnq"
tags: ["research", "reference"]
status: someday
type: project
created: 2021-10-19
updated: 2021-11-27
---

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

Links and tags are added randomly to create realistic relationships between notes.

[[Update-00023-cjg]] [[Idea-00006-oiw]]

## Concept-00032-bnq

Generated for large-vault performance testing.

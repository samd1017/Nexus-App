---
title: "Task-00266-mdb"
tags: ["important", "archive", "research"]
status: waiting
type: resource
created: 2024-07-21
updated: 2024-08-16
---

Random wikilinks exercise the backlink and local graph features.

Frontmatter properties allow testing of Bases and property-based queries.

## Task-00266-mdb

Generated for large-vault performance testing.

---
title: "Task-00055-xwl"
tags: ["important", "draft", "reference", "idea"]
status: waiting
type: project
created: 2023-10-31
updated: 2023-11-29
priority: low
---

Random wikilinks exercise the backlink and local graph features.

Dates and status values support filtering and sorting experiments.

Additional sentences help vary note size for full-text search testing.

## Task-00055-xwl

Generated for large-vault performance testing.

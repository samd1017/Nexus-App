---
title: "Task-00359-yny"
tags: ["writing", "idea", "note", "todo"]
status: archived
type: note
created: 2020-12-30
updated: 2021-01-06
priority: medium
due: 2021-01-06
---

Frontmatter properties allow testing of Bases and property-based queries.

Dates and status values support filtering and sorting experiments.

[[Brief-00163-esb]] [[Draft-00232-crg]]

## Task-00359-yny

Generated for large-vault performance testing.

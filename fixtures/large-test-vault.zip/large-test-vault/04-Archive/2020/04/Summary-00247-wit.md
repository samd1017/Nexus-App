---
title: "Summary-00247-wit"
tags: ["research", "important", "note", "reference"]
status: someday
type: resource
created: 2022-06-10
updated: 2022-06-12
priority: high
---

Random wikilinks exercise the backlink and local graph features.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Summary-00247-wit

Generated for large-vault performance testing.

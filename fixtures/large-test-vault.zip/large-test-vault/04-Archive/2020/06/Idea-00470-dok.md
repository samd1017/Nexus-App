---
title: "Idea-00470-dok"
tags: ["important", "research"]
status: someday
type: meeting
created: 2020-03-26
updated: 2020-04-04
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

[[Review-00036-fvq]] [[Task-00460-ixd]]

## Idea-00470-dok

Generated for large-vault performance testing.

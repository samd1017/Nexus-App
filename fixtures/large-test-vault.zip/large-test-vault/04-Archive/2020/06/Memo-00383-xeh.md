---
title: "Memo-00383-xeh"
tags: ["planning", "research"]
status: active
type: note
created: 2021-03-18
updated: 2021-04-14
priority: low
---

Frontmatter properties allow testing of Bases and property-based queries.

## Memo-00383-xeh

Generated for large-vault performance testing.

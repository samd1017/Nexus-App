---
title: "Review-00364-ert"
tags: ["todo", "planning"]
status: someday
type: person
created: 2025-09-23
updated: 2025-10-17
---

Random wikilinks exercise the backlink and local graph features.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Review-00364-ert

Generated for large-vault performance testing.

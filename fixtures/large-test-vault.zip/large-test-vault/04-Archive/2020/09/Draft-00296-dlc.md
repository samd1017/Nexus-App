---
title: "Draft-00296-dlc"
tags: ["research", "draft"]
status: reference
type: person
created: 2020-04-25
updated: 2020-06-04
---

Random wikilinks exercise the backlink and local graph features.

[[Research-00264-cfr]] [[Task-00097-fki]]

## Draft-00296-dlc

Generated for large-vault performance testing.

---
title: "Review-00213-zsh"
tags: ["planning", "note", "reference"]
status: done
type: meeting
created: 2021-03-12
updated: 2021-04-21
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

Frontmatter properties allow testing of Bases and property-based queries.

## Review-00213-zsh

Generated for large-vault performance testing.

---
title: "Task-00265-mae"
tags: ["review"]
status: active
type: person
created: 2023-01-08
updated: 2023-01-09
---

Random wikilinks exercise the backlink and local graph features.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Frontmatter properties allow testing of Bases and property-based queries.

## Task-00265-mae

Generated for large-vault performance testing.

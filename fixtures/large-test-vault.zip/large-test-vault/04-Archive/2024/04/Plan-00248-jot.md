---
title: "Plan-00248-jot"
tags: ["idea"]
status: waiting
type: project
created: 2022-05-20
updated: 2022-05-24
priority: high
---

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Links and tags are added randomly to create realistic relationships between notes.

## Plan-00248-jot

Generated for large-vault performance testing.

---
title: "Summary-00270-osb"
tags: ["finance"]
status: waiting
type: note
created: 2020-12-12
updated: 2021-01-24
---

Frontmatter properties allow testing of Bases and property-based queries.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Additional sentences help vary note size for full-text search testing.

[[Update-00023-cjg]] [[Note-00258-nbx]]

## Summary-00270-osb

Generated for large-vault performance testing.

---
title: "Plan-00328-jfn"
tags: ["archive", "reference", "finance"]
status: archived
type: area
created: 2020-05-11
updated: 2020-05-21
---

Dates and status values support filtering and sorting experiments.

## Plan-00328-jfn

Generated for large-vault performance testing.

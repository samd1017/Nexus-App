---
title: "Idea-00199-xkp"
tags: ["todo"]
status: reference
type: note
created: 2022-05-04
updated: 2022-05-24
---

Dates and status values support filtering and sorting experiments.

[[Update-00168-zst]] [[Research-00172-szd]] [[Log-00195-hxs]]

## Idea-00199-xkp

Generated for large-vault performance testing.

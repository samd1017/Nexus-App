---
title: "Brief-00381-htz"
tags: ["work", "reference", "meeting", "important"]
status: active
type: area
created: 2022-12-22
updated: 2022-12-25
due: 2023-02-10
---

Frontmatter properties allow testing of Bases and property-based queries.

## Brief-00381-htz

Generated for large-vault performance testing.

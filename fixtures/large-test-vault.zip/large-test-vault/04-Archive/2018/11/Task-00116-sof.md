---
title: "Task-00116-sof"
tags: ["reference", "personal", "note"]
status: active
type: person
created: 2020-06-20
updated: 2020-07-24
---

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

Links and tags are added randomly to create realistic relationships between notes.

## Task-00116-sof

Generated for large-vault performance testing.

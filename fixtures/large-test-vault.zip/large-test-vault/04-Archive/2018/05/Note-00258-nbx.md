---
title: "Note-00258-nbx"
tags: ["writing", "draft", "learning", "idea"]
status: done
type: project
created: 2022-08-23
updated: 2022-09-21
priority: low
due: 2022-09-07
---

Frontmatter properties allow testing of Bases and property-based queries.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

[[Log-00102-tdk]]

## Note-00258-nbx

Generated for large-vault performance testing.

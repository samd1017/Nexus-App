---
title: "Review-00395-vjq"
tags: ["project", "research", "draft"]
status: archived
type: area
created: 2020-01-17
updated: 2020-02-17
---

Links and tags are added randomly to create realistic relationships between notes.

Frontmatter properties allow testing of Bases and property-based queries.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

[[Idea-00005-epe]] [[Review-00085-fag]] [[Update-00161-ksq]]

## Review-00395-vjq

Generated for large-vault performance testing.

---
title: "Review-00402-tim"
tags: ["writing", "personal", "planning", "todo"]
status: active
type: daily
created: 2023-05-22
updated: 2023-05-27
---

Frontmatter properties allow testing of Bases and property-based queries.

## Review-00402-tim

Generated for large-vault performance testing.

---
title: "Idea-00378-kgg"
tags: ["health", "note", "writing", "todo"]
status: reference
type: meeting
created: 2020-03-21
updated: 2020-03-27
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Idea-00378-kgg

Generated for large-vault performance testing.

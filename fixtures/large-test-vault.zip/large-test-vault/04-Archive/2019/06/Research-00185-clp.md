---
title: "Research-00185-clp"
tags: ["todo", "note", "research", "reference"]
status: reference
type: project
created: 2024-05-12
updated: 2024-05-24
---

Frontmatter properties allow testing of Bases and property-based queries.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

Additional sentences help vary note size for full-text search testing.

## Research-00185-clp

Generated for large-vault performance testing.

---
title: "Idea-00344-hsh"
tags: ["work"]
status: archived
type: note
created: 2020-03-12
updated: 2020-03-25
---

Frontmatter properties allow testing of Bases and property-based queries.

Dates and status values support filtering and sorting experiments.

## Idea-00344-hsh

Generated for large-vault performance testing.

---
title: "Log-00433-nkj"
tags: ["note", "draft"]
status: someday
type: resource
created: 2020-03-26
updated: 2020-05-08
---

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Log-00433-nkj

Generated for large-vault performance testing.

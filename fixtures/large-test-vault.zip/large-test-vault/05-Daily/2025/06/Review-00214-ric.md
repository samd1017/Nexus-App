---
title: "Review-00214-ric"
tags: ["work"]
status: waiting
type: area
created: 2021-01-16
updated: 2021-02-11
---

Random wikilinks exercise the backlink and local graph features.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Review-00214-ric

Generated for large-vault performance testing.

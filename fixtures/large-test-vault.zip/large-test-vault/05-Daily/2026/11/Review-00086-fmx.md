---
title: "Review-00086-fmx"
tags: ["reference", "draft", "review", "health"]
status: someday
type: project
created: 2021-06-26
updated: 2021-07-12
priority: medium
---

Frontmatter properties allow testing of Bases and property-based queries.

## Review-00086-fmx

Generated for large-vault performance testing.

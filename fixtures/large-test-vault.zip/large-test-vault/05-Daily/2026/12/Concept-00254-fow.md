---
title: "Concept-00254-fow"
tags: ["research", "finance", "work"]
status: done
type: project
created: 2023-03-14
updated: 2023-03-30
priority: low
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Links and tags are added randomly to create realistic relationships between notes.

## Concept-00254-fow

Generated for large-vault performance testing.

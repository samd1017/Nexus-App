---
title: "Plan-00182-jwi"
tags: ["research", "work", "project"]
status: done
type: meeting
created: 2024-05-02
updated: 2024-05-28
due: 2024-07-06
---

Frontmatter properties allow testing of Bases and property-based queries.

[[Note-00088-ybl]]

## Plan-00182-jwi

Generated for large-vault performance testing.

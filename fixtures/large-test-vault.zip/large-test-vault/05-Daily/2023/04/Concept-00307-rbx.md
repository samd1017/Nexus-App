---
title: "Concept-00307-rbx"
tags: ["planning"]
status: done
type: resource
created: 2020-01-13
updated: 2020-02-10
---

Additional sentences help vary note size for full-text search testing.

This is a generic test note generated for large vault performance testing.

Random wikilinks exercise the backlink and local graph features.

## Concept-00307-rbx

Generated for large-vault performance testing.

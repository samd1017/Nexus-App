---
title: "Research-00319-lkb"
tags: ["work", "draft", "todo", "archive"]
status: waiting
type: resource
created: 2021-02-23
updated: 2021-02-25
priority: high
---

Links and tags are added randomly to create realistic relationships between notes.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Frontmatter properties allow testing of Bases and property-based queries.

[[Task-00068-anh]] [[Concept-00134-xdf]] [[Plan-00197-xbt]]

## Research-00319-lkb

Generated for large-vault performance testing.

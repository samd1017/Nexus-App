---
title: "Plan-00201-qbv"
tags: ["todo", "planning", "project", "personal"]
status: done
type: area
created: 2020-04-11
updated: 2020-04-19
---

Random wikilinks exercise the backlink and local graph features.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

## Plan-00201-qbv

Generated for large-vault performance testing.

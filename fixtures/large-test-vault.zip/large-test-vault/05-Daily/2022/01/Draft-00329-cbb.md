---
title: "Draft-00329-cbb"
tags: ["health", "work"]
status: waiting
type: project
created: 2021-12-21
updated: 2022-01-08
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Random wikilinks exercise the backlink and local graph features.

## Draft-00329-cbb

Generated for large-vault performance testing.

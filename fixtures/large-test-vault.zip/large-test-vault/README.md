# Large Test Vault

Generated for performance testing of note-taking apps (Obsidian, etc.).

- **Notes**: 45,000
- **Seed**: 42
- **Generated**: 2026-08-04 02:56

## Structure

| Folder | Purpose |
|--------|---------|
| 00-Inbox | Unprocessed notes |
| 01-Projects | 20 projects with Notes/Meetings subfolders |
| 02-Areas | Ongoing areas |
| 03-Resources | Reference material |
| 04-Archive | Large cold-storage section (year/month) — good for exclusion tests |
| 05-Daily | Daily notes by year/month |
| 06-People | Person notes |
| 07-Topics | Topic notes |
| 08-Meetings | Meeting notes |

## Note content

Each note has YAML frontmatter (`title`, `tags`, `status`, `type`, `created`, `updated`,
sometimes `priority` / `due`), short body text, and occasional `[[wikilinks]]`.

## How to use

1. Unzip this archive.
2. Open the `large-test-vault` folder as a vault in your app (Obsidian desktop or mobile).
3. Let initial indexing finish (can take a while the first time).
4. Test search, graph, backlinks, Bases, startup time, and mobile behavior.
5. Try excluding `04-Archive` from graph/search on mobile.

Tip: On first mobile open of a huge vault, start with a subset or exclude Archive.

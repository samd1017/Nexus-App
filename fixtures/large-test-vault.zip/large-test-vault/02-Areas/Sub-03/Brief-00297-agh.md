---
title: "Brief-00297-agh"
tags: ["writing", "draft"]
status: someday
type: project
created: 2021-08-17
updated: 2021-08-24
due: 2021-09-17
---

Frontmatter properties allow testing of Bases and property-based queries.

[[Memo-00143-dce]]

## Brief-00297-agh

Generated for large-vault performance testing.

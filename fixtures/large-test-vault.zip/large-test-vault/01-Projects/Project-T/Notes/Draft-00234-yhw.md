---
title: "Draft-00234-yhw"
tags: ["important", "idea"]
status: archived
type: resource
created: 2021-11-15
updated: 2021-12-02
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

Dates and status values support filtering and sorting experiments.

Frontmatter properties allow testing of Bases and property-based queries.

## Draft-00234-yhw

Generated for large-vault performance testing.

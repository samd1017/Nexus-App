---
title: "Concept-00090-pzr"
tags: ["reference"]
status: reference
type: daily
created: 2025-12-01
updated: 2025-12-18
priority: low
---

Frontmatter properties allow testing of Bases and property-based queries.

Links and tags are added randomly to create realistic relationships between notes.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

## Concept-00090-pzr

Generated for large-vault performance testing.

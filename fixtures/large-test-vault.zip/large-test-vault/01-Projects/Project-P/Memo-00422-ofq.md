---
title: "Memo-00422-ofq"
tags: ["personal"]
status: someday
type: area
created: 2021-06-27
updated: 2021-08-09
---

Random wikilinks exercise the backlink and local graph features.

Frontmatter properties allow testing of Bases and property-based queries.

Additional sentences help vary note size for full-text search testing.

[[Research-00048-rxp]] [[Brief-00278-yoi]]

## Memo-00422-ofq

Generated for large-vault performance testing.

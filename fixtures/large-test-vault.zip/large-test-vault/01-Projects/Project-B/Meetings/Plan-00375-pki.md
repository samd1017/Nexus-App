---
title: "Plan-00375-pki"
tags: ["finance", "reference", "idea"]
status: waiting
type: project
created: 2022-02-20
updated: 2022-03-10
priority: medium
---

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Links and tags are added randomly to create realistic relationships between notes.

## Plan-00375-pki

Generated for large-vault performance testing.

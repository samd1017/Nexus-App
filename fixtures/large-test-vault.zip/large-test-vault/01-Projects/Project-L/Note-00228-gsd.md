---
title: "Note-00228-gsd"
tags: ["planning"]
status: waiting
type: project
created: 2020-07-13
updated: 2020-07-26
priority: low
---

Frontmatter properties allow testing of Bases and property-based queries.

Additional sentences help vary note size for full-text search testing.

## Note-00228-gsd

Generated for large-vault performance testing.

---
title: "Task-00188-pvq"
tags: ["note"]
status: waiting
type: resource
created: 2023-12-08
updated: 2023-12-17
---

Random wikilinks exercise the backlink and local graph features.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

[[Plan-00115-acn]]

## Task-00188-pvq

Generated for large-vault performance testing.

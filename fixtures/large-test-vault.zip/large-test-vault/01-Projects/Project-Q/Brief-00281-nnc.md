---
title: "Brief-00281-nnc"
tags: ["important", "writing"]
status: reference
type: note
created: 2024-11-02
updated: 2024-11-09
---

Random wikilinks exercise the backlink and local graph features.

Frontmatter properties allow testing of Bases and property-based queries.

## Brief-00281-nnc

Generated for large-vault performance testing.

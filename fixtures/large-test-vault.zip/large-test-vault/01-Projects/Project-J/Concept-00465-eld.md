---
title: "Concept-00465-eld"
tags: ["planning"]
status: archived
type: resource
created: 2022-08-22
updated: 2022-08-23
---

Frontmatter properties allow testing of Bases and property-based queries.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Links and tags are added randomly to create realistic relationships between notes.

## Concept-00465-eld

Generated for large-vault performance testing.

---
title: "Task-00318-bxr"
tags: ["planning", "writing"]
status: reference
type: note
created: 2022-08-14
updated: 2022-09-17
---

Random wikilinks exercise the backlink and local graph features.

Links and tags are added randomly to create realistic relationships between notes.

This is a generic test note generated for large vault performance testing.

## Task-00318-bxr

Generated for large-vault performance testing.

---
title: "Memo-00162-sxq"
tags: ["work"]
status: waiting
type: area
created: 2022-12-15
updated: 2023-01-13
---

Dates and status values support filtering and sorting experiments.

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

## Memo-00162-sxq

Generated for large-vault performance testing.

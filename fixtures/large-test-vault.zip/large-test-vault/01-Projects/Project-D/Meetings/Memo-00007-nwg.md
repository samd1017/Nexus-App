---
title: "Memo-00007-nwg"
tags: ["writing"]
status: reference
type: daily
created: 2024-11-08
updated: 2024-11-21
---

Frontmatter properties allow testing of Bases and property-based queries.

## Memo-00007-nwg

Generated for large-vault performance testing.

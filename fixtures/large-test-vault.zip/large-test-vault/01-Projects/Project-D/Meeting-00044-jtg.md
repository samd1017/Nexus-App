---
title: "Meeting-00044-jtg"
tags: ["writing"]
status: archived
type: resource
created: 2023-04-05
updated: 2023-05-15
---

Frontmatter properties allow testing of Bases and property-based queries.

Random wikilinks exercise the backlink and local graph features.

Additional sentences help vary note size for full-text search testing.

## Meeting-00044-jtg

Generated for large-vault performance testing.

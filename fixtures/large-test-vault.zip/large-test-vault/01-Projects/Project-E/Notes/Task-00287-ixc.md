---
title: "Task-00287-ixc"
tags: ["work", "review"]
status: done
type: area
created: 2023-05-17
updated: 2023-06-10
---

The goal is to stress indexing, startup time, memory usage, and mobile behavior.

It contains placeholder content so the metadata cache, search, and graph can be exercised.

Links and tags are added randomly to create realistic relationships between notes.

## Task-00287-ixc

Generated for large-vault performance testing.

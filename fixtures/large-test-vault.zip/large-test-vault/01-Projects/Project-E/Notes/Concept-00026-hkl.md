---
title: "Concept-00026-hkl"
tags: ["important"]
status: done
type: project
created: 2024-10-24
updated: 2024-11-07
due: 2025-01-18
---

Frontmatter properties allow testing of Bases and property-based queries.

Dates and status values support filtering and sorting experiments.

Random wikilinks exercise the backlink and local graph features.

[[Update-00022-lfr]] [[Brief-00008-fnk]]

## Concept-00026-hkl

Generated for large-vault performance testing.
